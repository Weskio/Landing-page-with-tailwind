import React from 'react';
import Landing from './Landing';

export default function App() {
  return (
    <div>
      <Landing/>
    </div>
  )
}